/**
 * 
 */
package com.crossover.techtrial.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RestResource;

import com.crossover.techtrial.model.Transaction;

/**
 * @author crossover
 *
 */
@RestResource(exported = false)
public interface TransactionRepository extends CrudRepository<Transaction, Long> {

	@Query("SELECT COUNT(*) FROM Transaction t WHERE t.book.id = :bookId AND t.dateOfIssue is not null AND t.dateOfReturn is null")
	public Long checkIfBookAlreadyIssued(@Param(value = "bookId") Long bookId);
	
	public boolean existsById(Long bookId);
	
	@Query("SELECT COUNT(*) FROM Transaction t WHERE t.id = :transactionId AND t.dateOfReturn is not null")
	public Long isTransactionCompleted(@Param(value = "transactionId") Long transactionId);
	
	@Query("SELECT COUNT(*) FROM Transaction t WHERE t.member.id = :memberId AND t.dateOfIssue is not null AND t.dateOfReturn is null")
	public Long checkNumberOfBooksIssuedSoFar(@Param(value = "memberId") Long memberId);
	
}
