/**
 * 
 */
package com.crossover.techtrial.model;

/**
 * @author kshah
 *
 */
public enum MembershipStatus {
  ACTIVE,
  INACTIVE,
  BLOCKED
}
