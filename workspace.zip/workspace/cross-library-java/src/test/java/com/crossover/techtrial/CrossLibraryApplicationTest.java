/**
 * 
 */
package com.crossover.techtrial;

/**
 * @author crossover
 *
 */
public class CrossLibraryApplicationTest {

}
