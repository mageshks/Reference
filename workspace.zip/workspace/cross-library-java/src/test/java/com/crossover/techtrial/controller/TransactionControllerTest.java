package com.crossover.techtrial.controller;

import static org.junit.Assert.assertNotNull;

import java.util.Map;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.crossover.techtrial.model.Transaction;
import com.crossover.techtrial.repositories.TransactionRepository;

/**
 * @author Magesh
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class TransactionControllerTest {

	MockMvc mockMvc;

	@Mock
	private TransactionController transactionController;

	@Autowired
	private TestRestTemplate template;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Before
	public void setup() throws Exception {
		mockMvc = MockMvcBuilders.standaloneSetup(transactionController).build();
	}
	
	@Test
	public void testIssueBookToMemberSuccessful() throws Exception {

		HttpEntity<Object> param = getHttpEntity(
				"{\"bookId\": \"1\", \"memberId\": \"4\" }");

		ResponseEntity<Transaction> response = template.postForEntity("/api/transaction", param, Transaction.class);
		
		Assert.assertEquals(200, response.getStatusCode().value());
		
		// cleanup the transaction
		transactionRepository.deleteById(response.getBody().getId());
	}

	@Test
	public void testReturnBookSuccessfulTransaction()throws Exception {
		long transactionId = 1;

		ResponseEntity<Map> response = template.postForEntity("/api/transaction/"+ transactionId +"/return", null, Map.class);
		System.out.println("Response status code " + response.getStatusCode().value() );
		Assert.assertEquals(200, response.getStatusCode().value());
	}
	
	
	@Test
	public void testBookDateOfIssue() throws Exception {

		HttpEntity<Object> param = getHttpEntity(
				"{\"bookId\": \"2\", \"memberId\": \"1\" }");

		ResponseEntity<Map> response = template.postForEntity("/api/transaction", param, Map.class);
		
		assertNotNull(response.getBody().get("dateOfIssue"));

	}
	
	@Test
	public void testIfBookAlreadyIssued() throws Exception {

		HttpEntity<Object> param = getHttpEntity(
				"{\"bookId\": \"1\", \"memberId\": \"1\" }");

		ResponseEntity<Map> response = template.postForEntity("/api/transaction", param, Map.class);

		Assert.assertEquals(403, response.getStatusCode().value());

	}

	@Test
	public void testBookUnavailability() throws Exception{
		HttpEntity<Object> param = getHttpEntity(
				"{\"bookId\": \"4\" }");

		ResponseEntity<Map> response = template.postForEntity("/api/transaction", param, Map.class);

		Assert.assertEquals(404, response.getStatusCode().value());
	}
	
	@Test
	public void testBookAvailability() throws Exception{
		HttpEntity<Object> param = getHttpEntity(
				"{\"bookId\": \"1\" }");

		ResponseEntity<Map> response = template.postForEntity("/api/transaction", param, Map.class);
		Assert.assertEquals(200, response.getStatusCode().value());
	}
	
	@Test
	public void testNumberOfBooksIssuedSoFar() throws Exception{
		HttpEntity<Object> param = getHttpEntity(
				"{\"memberId\": \"1\" }");
		ResponseEntity<Map> response = template.postForEntity("/api/transaction", param, Map.class);
		Assert.assertEquals(403, response.getStatusCode().value());
	}

	private HttpEntity<Object> getHttpEntity(Object body) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		return new HttpEntity<Object>(body, headers);
	}
	
}
